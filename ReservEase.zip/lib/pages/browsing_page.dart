import 'package:flutter/material.dart';
import 'profile_page.dart';
import 'restaurant_page.dart';

class BrowsingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: buildBody(context),
      ),
    );
  }

  Widget buildBody(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 20),
          buildDivider(color: Colors.red),
          SizedBox(height: 20),
          buildWelcomeMessage(),
          SizedBox(height: 20),
          buildDivider(color: Colors.grey),
          SizedBox(height: 20),
          buildSectionTitle("All Restaurants"),
          SizedBox(height: 20),
          buildGridView(),
          SizedBox(height: 20),
          Container(
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(color: Colors.grey, width: 1.0),
              ),
            ),
            child: buildBottomNavigation(context),
          ),
        ],
      ),
    );
  }

  Container buildDivider({required Color color}) {
    return Container(
      color: color,
      width: 337,
      height: 2,
    );
  }

  Container buildWelcomeMessage() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            "Welcome to ReservEase",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(width: 10),
          Container(
            width: 40,
            height: 40,
            child: CircleAvatar(
              backgroundImage: AssetImage('lib/assets/icon.jpg'),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 20.0),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget buildGridView() {
    return Expanded(
      child: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 20,
          mainAxisSpacing: 20,
        ),
        itemCount: 6,
        itemBuilder: (BuildContext context, int index) {
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => RestaurantPage()),
              );
            },
            child: buildPictureWithBox(index),
          );
        },
      ),
    );
  }

  Container buildPictureWithBox(int index) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.black,
          width: 2,
        ),
        borderRadius: BorderRadius.circular(5),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 60,
            child: Image.asset(
              'lib/assets/yellowcab.jpg',
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(height: 5),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Yellow Cab Pizza co. ",
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  "G/F Vista Mall Naga, Naga, 4400 Camarines Sur",
                  style: TextStyle(
                    fontSize: 8,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  "10:00 AM - 09:00 PM",
                  style: TextStyle(
                    fontSize: 8,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 5),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              buildRedRectangle("8:00"),
              buildRedRectangle("12:00"),
              buildRedRectangle("18:00"),
            ],
          ),
        ],
      ),
    );
  }

  Container buildRedRectangle(String text) {
    return Container(
      width: 35,
      height: 18,
      margin: EdgeInsets.symmetric(horizontal: 2),
      color: Colors.red,
      child: Center(
        child: Text(
          text,
          style: TextStyle(
            color: Colors.white,
            fontSize: 10,
          ),
        ),
      ),
    );
  }

  Widget buildBottomNavigation(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          buildNavigationItem(Icons.home, "Home", color: Colors.red),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileScreen()),
              );
            },
            child: buildNavigationItem(Icons.more_horiz, "More"),
          ),
        ],
      ),
    );
  }

  Widget buildNavigationItem(IconData icon, String text,
      {Color? color, VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Icon(
            icon,
            color: color,
          ),
          Text(
            text,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
