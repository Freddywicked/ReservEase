import 'package:flutter/material.dart';
import 'browsing_page.dart';

class ReservationPopup extends StatefulWidget {
  final DateTime pickedDate;
  final String pickedTime;

  ReservationPopup({required this.pickedDate, required this.pickedTime});

  @override
  _ReservationPopupState createState() => _ReservationPopupState();
}

class _ReservationPopupState extends State<ReservationPopup> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();
  final TextEditingController numberOfGuestsController =
      TextEditingController();

  String errorMessage = '';

  @override
  Widget build(BuildContext context) {
    String formattedDate =
        '${widget.pickedDate.year}-${_formatNumber(widget.pickedDate.month)}-${_formatNumber(widget.pickedDate.day)}';

    return Scaffold(
      appBar: AppBar(
        title: Text('Go back'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Row(
              children: [
                Icon(
                  Icons.calendar_today_rounded,
                  color: Colors.red,
                  size: 24,
                ),
                SizedBox(width: 20),
                Text(
                  formattedDate,
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 10),
                Text(
                  '|',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 10),
                Text(
                  widget.pickedTime,
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Icon(
                  Icons.place,
                  color: Colors.red,
                  size: 24,
                ),
                SizedBox(width: 20),
                Text(
                  'YELLOW CAB Pizza co.',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 20),
            _buildTextFieldWithLabel("Full Name", nameController),
            SizedBox(height: 20),
            _buildTextFieldWithLabel("Phone Number", phoneNumberController),
            SizedBox(height: 20),
            _buildTextFieldWithLabel(
                "Number of Guests", numberOfGuestsController),
            SizedBox(height: 10),
            if (errorMessage.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 10.0),
                child: Text(
                  errorMessage,
                  style: TextStyle(color: Colors.red),
                ),
              ),
            GestureDetector(
              onTap: () {
                if (_validateFields()) {
                  _showPopup(widget.pickedTime, widget.pickedDate);
                } else {
                  setState(() {
                    errorMessage = 'Please fill in all fields.';
                  });
                }
              },
              child: Container(
                width: double.infinity,
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.red,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Center(
                  child: Text(
                    'Reserve Now',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextFieldWithLabel(
      String label, TextEditingController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(fontSize: 16),
        ),
        SizedBox(height: 10),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey),
            borderRadius: BorderRadius.circular(5),
          ),
          child: TextField(
            controller: controller,
            decoration: InputDecoration(
              border: InputBorder.none,
              hintText: "",
            ),
          ),
        ),
      ],
    );
  }

  String _formatNumber(int number) {
    return number.toString().padLeft(2, '0');
  }

  bool _validateFields() {
    return nameController.text.isNotEmpty &&
        phoneNumberController.text.isNotEmpty &&
        numberOfGuestsController.text.isNotEmpty;
  }

  void _showPopup(String pickedTime, DateTime pickedDate) {
    String formattedDate =
        '${pickedDate.year}-${_formatNumber(pickedDate.month)}-${_formatNumber(pickedDate.day)}';

    String guestsText =
        numberOfGuestsController.text == '1' ? 'guest' : 'guests';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return WillPopScope(
          onWillPop: () async {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => BrowsingPage()),
            );
            return true;
          },
          child: AlertDialog(
            backgroundColor: Color.fromRGBO(51, 51, 51, 0.67),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.check_circle,
                      color: Colors.white,
                      size: 50,
                    ),
                  ],
                ),
                SizedBox(height: 10),
                Text(
                  'Table booked successfully',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  height: 1,
                  color: Colors.red,
                ),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '${nameController.text} | ${phoneNumberController.text}',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                Container(
                  height: 1,
                  color: Colors.red,
                ),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.calendar_today_rounded,
                      color: Colors.red,
                      size: 24,
                    ),
                    SizedBox(width: 10),
                    Text(
                      '$formattedDate | $pickedTime',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.people,
                      color: Colors.red,
                      size: 24,
                    ),
                    SizedBox(width: 10),
                    Text(
                      '${numberOfGuestsController.text} $guestsText',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20),
                Container(
                  height: 1,
                  color: Colors.red,
                ),
                SizedBox(height: 20),
                Text(
                  'Your table is reserved!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
