import 'package:flutter/material.dart';
import 'timeslot.dart';

class RestaurantPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('YELLOW CAB Pizza co.'),
          centerTitle: true,
        ),
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 2,
                color: Colors.red,
              ),
              SizedBox(height: 20),
              Center(
                child: Container(
                  height: 120,
                  width: 320,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: Image.asset(
                      'lib/assets/yellowcab.jpg',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Row(
                children: [
                  Icon(
                    Icons.place,
                    color: Colors.red,
                  ),
                  SizedBox(width: 5),
                  Flexible(
                    child: Text(
                      'G/F Vista Mall Naga, Naga, 4400 Camarines Sur',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 12,
                      ),
                      softWrap: true,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Icon(
                    Icons.access_time,
                    color: Colors.red,
                  ),
                  SizedBox(width: 5),
                  Text(
                    '10:00 AM - 09:00 PM',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Text(
                'About',
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text(
                'In April 2001, Yellow Cab Pizza Co. opened its first branch in the Philippines. Since then, we have opened over 200 restaurants throughout the world. Our Honolulu, Hawaii branch will be our first location in the United States.',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Our New York-style pizza is made with premium ingredients and generous toppings. Our crust is crisp and slightly charred on the bottom, dense and chewy in the middle, and slightly gooey on top. And that\'s just the crust. Top it off with a generous serving of the freshest, highest-quality ingredients, and you get—simply put—great pizza.',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 12,
                ),
              ),
              SizedBox(height: 20),
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      'Select a date you prefer',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(width: 10),
                    IconButton(
                      icon: Icon(Icons.calendar_today),
                      onPressed: () {
                        _showDatePicker(context);
                      },
                      color: Colors.red,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showDatePicker(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(DateTime.now().year - 1),
      lastDate: DateTime(DateTime.now().year + 1),
    );
    if (picked != null) {
      print('Selected date: $picked');

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => TimeslotPage(pickedDate: picked),
        ),
      );
    }
  }
}
