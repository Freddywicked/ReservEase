import 'package:flutter/material.dart';
import 'reservation_popup.dart';

class TimeslotPage extends StatefulWidget {
  final DateTime pickedDate;

  TimeslotPage({required this.pickedDate});

  @override
  _TimeslotPageState createState() => _TimeslotPageState();
}

class _TimeslotPageState extends State<TimeslotPage> {
  int selectedTimeIndex = -1;
  bool confirmVisible = false;
  String pickedTime = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('YELLOW CAB Pizza co.'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 2,
                color: Colors.red,
              ),
              SizedBox(height: 20),
              Center(
                child: Container(
                  height: 120,
                  width: 320,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: Image.asset(
                      'lib/assets/yellowcab.jpg',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Row(
                children: [
                  Icon(
                    Icons.place,
                    color: Colors.red,
                  ),
                  SizedBox(width: 5),
                  Flexible(
                    child: Text(
                      'G/F Vista Mall Naga, Naga, 4400 Camarines Sur',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 12,
                      ),
                      softWrap: true,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Icon(
                    Icons.access_time,
                    color: Colors.red,
                  ),
                  SizedBox(width: 5),
                  Text(
                    '10:00 AM - 09:00 PM',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Center(
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Color(0xffff0000),
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.date_range,
                        color: Color(0xffffffff),
                        size: 16,
                      ),
                      SizedBox(width: 5),
                      Text(
                        'Selected Date: ${widget.pickedDate.day}/${widget.pickedDate.month}/${widget.pickedDate.year}',
                        style: TextStyle(
                          color: Color(0xffffffff),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10),
              if (!confirmVisible)
                Center(
                  child: Text(
                    'Select a time you like',
                    style: TextStyle(
                      fontSize: 12,
                    ),
                  ),
                ),
              SizedBox(height: 20),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      buildTimeContainer('8:00', 0),
                      buildTimeContainer('12:00', 1),
                      buildTimeContainer('18:00', 2),
                    ],
                  ),
                  SizedBox(height: 20),
                  if (confirmVisible) buildConfirmButton(),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildTimeContainer(String time, int index) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedTimeIndex = index;
          confirmVisible = true;
          pickedTime = time;
        });
      },
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: 70,
          height: 30,
          color: selectedTimeIndex == index ? Colors.red : Colors.grey,
          child: Center(
            child: Text(
              time,
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildConfirmButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        width: double.infinity,
        height: 30,
        color: Colors.red,
        child: Center(
          child: ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ReservationPopup(
                    pickedDate: widget.pickedDate,
                    pickedTime: pickedTime,
                  ),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              primary: Colors.red,
              padding: EdgeInsets.zero,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(0),
              ),
            ),
            child: Container(
              child: Center(
                child: Text(
                  'Confirm',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
